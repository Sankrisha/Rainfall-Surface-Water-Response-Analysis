# Rainfall–Surface Water Analysis

Streamlit dashboard for analyzing rainfall and surface-water availability.

## Files
- app.py — dashboard application
- requirements.txt — required packages
- sample_rainfall_surface_water.csv — sample data

## CSV columns
Your uploaded CSV should contain:
- Date
- Rainfall_mm
- Water_Area_km2

## Streamlit Community Cloud
1. Create a GitHub repository.
2. Upload the files from this ZIP.
3. Open Streamlit Community Cloud.
4. Connect your GitHub account.
5. Select the repository.
6. Select the `main` branch.
7. Set the main file to `app.py`.
8. Click Deploy.
